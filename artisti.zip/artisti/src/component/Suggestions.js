import { React, Component } from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBBtn,
  MDBIcon,
  MDBInput,
} from "mdbreact";
export default class Suggestions extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userName: "",
      text: "",
      subject: "",
      email: "",
      suggested: false,
    };
  }
  changeemailHandler = (event) => {
    this.setState({ email: event.target.value });
  };
  changetextHandler = (event) => {
    this.setState({ text: event.target.value });
  };
  changelsnameHandler = (event) => {
    this.setState({
      userName: event.target.value,
    });
  };
  changeSubjectHandler = (event) => {
    this.setState({
      subject: event.target.value,
    });
  };
  submit = (event) => {
    this.setState({ suggested: true });
    event.preventDefault();
    console.log("email:", this.state.email);
    console.log("myname:", this.state.userName);
  };
  render() {
    if (this.state.suggested == true) {
        return (
          <div>
            <div className="thankYou">
              <h3>Thanks for your valuable feedback {this.state.userName}.</h3>
            </div>
            <div style={{textAlign:"center"}}>
              <b>We will look into it</b>
            </div>
          </div>
        );
      }
    return (
      <MDBContainer className="suggestionForm">
        <MDBRow>
          <MDBCol md="6">
            <form>
              <p className="h5 text-center mb-4">Write to us</p>
              <div className="grey-text">
                <MDBInput
                  label="Your name"
                  icon="user"
                  group
                  type="text"
                  validate
                  error="wrong"
                  success="right"
                  onChange={this.changelsnameHandler.bind(this)}
                  value={this.state.userName}
                />
                <MDBInput
                  label="Your email"
                  icon="envelope"
                  group
                  type="email"
                  validate
                  error="wrong"
                  success="right"
                  onChange={this.changeemailHandler.bind(this)}
                  value={this.state.email}
                />
                <MDBInput
                  label="Subject"
                  icon="tag"
                  group
                  type="text"
                  validate
                  error="wrong"
                  success="right"
                  onChange={this.changeSubjectHandler.bind(this)}
                  value={this.state.subject}
                />
                <MDBInput
                  type="textarea"
                  rows="2"
                  label="Your message"
                  icon="pencil-alt"
                  onChange={this.changetextHandler.bind(this)}
                  value={this.state.text}
                />
              </div>
              <div className="text-center">
                <MDBBtn
                  outline
                  color="secondary"
                  onClick={this.submit.bind(this)}
                >
                  Send
                  <MDBIcon far icon="paper-plane" className="ml-1" />
                </MDBBtn>
              </div>
            </form>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    );
  }
}
