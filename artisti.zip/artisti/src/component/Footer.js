import React from "react";
const Footer = () => {
  return (
    <div>
      <footer
        style={{
          backgroundColor: "grey",
          position: "fixed",
          left: "0",
          bottom: "0",
          height: "50px",
          width: "100%",
          overflow:"auto"
        }}
      >
        <text>
          <h4
            style={{
              alignContent: "center",
              paddingLeft: "450px",
              paddingTop: "10px",
            }}
          >
            <b> ©2020 Heartisiti All Rights Reserved</b>
          </h4>
        </text>
      </footer>
    </div>
  );
};
export default Footer;
