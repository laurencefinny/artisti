import { render } from "@testing-library/react";
import React, { Component } from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBBtn,
  MDBIcon,
  MDBInput,
  MDBTable,
} from "mdbreact";
class About extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div>
        <MDBContainer className="about">
          <MDBRow>
            <h1>Artisti & co</h1>
          </MDBRow>
        </MDBContainer>
        <MDBContainer>
          <div>
            <h4>
              <p>we do</p>
            </h4>
            <ol>
              <li>
                <p>Wall Arts</p>
              </li>
              <li>
                <p>Potraits</p>
              </li>
              <li>
                <p>Abstracts</p>
              </li>
            </ol>
          </div>
        </MDBContainer>
        <MDBContainer>
          <div>
            <u>
              <b>
                CONTACT INFORMATION
                <span
                  class="material-icons sm"
                  style={{ verticalAlign: "-5px" }}
                >
                  phone
                </span>
                :
              </b>
            </u>
            {"         "}
            9603340903
          </div>
          <div>
            <u>
              <b>
                ADDRESS:<span  class="material-icons sm">home</span>
              </b>
            </u>
            {" "}
            D/NO 19-14-23, S.P.Street, Bhimavaram, 534201
          </div>
        </MDBContainer>
      </div>
    );
  }
}
export default About;
