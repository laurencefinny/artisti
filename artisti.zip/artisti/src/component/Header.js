import React, { Component } from "react";
//import 'bootstrap/dist/css/bootstrap.min.css';
import {
  Navbar,
  Nav,
  NavDropdown,
  Form,
  FormControl,
  Button,
} from "react-bootstrap";

class Header extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: [],
      dataUnReg: [],
    };
  }
  render() {
    return (
      <Navbar bg="light" expand="lg">
        <Navbar.Brand href="/home">
          <h3>
            <b>
              Artisti <span class="material-icons">palette</span>
            </b>
          </h3>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
            <Nav.Link href="/about">About</Nav.Link>
            <Nav.Link href="/placeOrder">Place order</Nav.Link>
          </Nav>
          <Form inline>
            <FormControl type="text" placeholder="Search" className="mr-sm-2" />
            <Button variant="outline-success">Search</Button>
          </Form>
        </Navbar.Collapse>
      </Navbar>
    );
  }
}
export default Header;
