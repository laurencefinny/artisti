import logo from "./logo.svg";
import "./App.css";
import Header from "./component/Header";
import Footer from "./component/Footer";
import Home from "./component/Home";
import PlaceOrder from "./component/PlaceOrder";
import About from "./component/About"
import Subscribe from "./component/Subscribe"
import Suggestions from "./component/Suggestions"
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

function App() {
  return (
    <Router>
      {window.location.pathname === "/" ? <Header /> : <Header />}
      <Switch>
        <Route path="/placeOrder" component={PlaceOrder} />
      </Switch>
      <Switch>
        <Route path="/home" component={Home} />
      </Switch>
      <Switch>
        <Route path="/about" component={About} />
      </Switch>
      <Switch>
        <Route path="/subscribe" component={Subscribe} />
      </Switch>
      <Switch>
        <Route path="/suggestions" component={Suggestions} />
      </Switch>
      
    </Router>
  );
}

export default App;
